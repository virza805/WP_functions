<?php
/*
  Name: Just button
 */
?>
<?php include(rh_locate_template('inc/ce_common/data_button.php')); ?>         