<?php /* Template Name: Blank */
edit_post_link();
the_post();
the_content();