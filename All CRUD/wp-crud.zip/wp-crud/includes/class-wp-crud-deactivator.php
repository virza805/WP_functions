<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://vir-za.com
 * @since      1.0.0
 *
 * @package    Wp_Crud
 * @subpackage Wp_Crud/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wp_Crud
 * @subpackage Wp_Crud/includes
 * @author     Tanvir <01mdalamin1@gmail.com>
 */
class Wp_Crud_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
