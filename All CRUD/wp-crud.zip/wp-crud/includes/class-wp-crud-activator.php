<?php

/**
 * Fired during plugin activation
 *
 * @link       https://vir-za.com
 * @since      1.0.0
 *
 * @package    Wp_Crud
 * @subpackage Wp_Crud/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wp_Crud
 * @subpackage Wp_Crud/includes
 * @author     Tanvir <01mdalamin1@gmail.com>
 */
class Wp_Crud_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
