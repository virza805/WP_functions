<div class='eac-settings'>
	<ul class="tabs-nav">
		<li class=""><a href="#tab-1" rel="nofollow"><?php esc_html_e('Avancés', 'eac-components'); ?></a></li>
		<li class=""><a href="#tab-2" rel="nofollow"><?php esc_html_e('Composants', 'eac-components'); ?></a></li>
		<li class=""><a href="#tab-3" rel="nofollow"><?php esc_html_e('Fonctionnalités', 'eac-components'); ?></a></li>
		<li class="tab-active"><a href="#tab-4" rel="nofollow"><?php echo 'Wordpress'; ?></a></li>
	</ul>
</div>