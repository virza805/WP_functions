<div>
	<div class="eac-header-settings">
		<div>
			<img class="eac-logo" src="<?php echo EAC_ADDONS_URL . 'admin/images/EAC-coollogo.png';?>" />
		</div>
		<div>
			<h1 class="eac-title-main"><?php esc_html_e('Elementor Addon Components', 'eac-components'); ?></h1>
			<h2 class="eac-title-sub"><?php esc_html_e("Ajouter des composants et des fonctionnalités avancées pour la version gratuite d'Elementor", "eac-components"); ?></h2>
			<p class="eac-title-version">Version: <?php echo EAC_ADDONS_VERSION; ?></p>
		</div>
	</div>
</div>